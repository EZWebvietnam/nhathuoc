
<div id="wapper_login">
        <!--<div class="name_product"></div>-->
        <div class="content" id="content">
            <form  method="post" accept-charset="utf-8"> 
<div class="swap_input" style="margin-top: 52px; ">
    <div class="label">Email</div>
    <input type="text" name="email"/>
</div>

<div class="account_login">
    
</div>
<input type="submit" class="button_login" title="Đăng nhập" id="btnDangnhap" value="Đăng nhập" name="btnDangnhap">
</form></div>
        </div>
        <!--<div class="version">Version: 2.0</div>
        <div class="copy">Copyright 2010 - All rights reserved.</div>-->
    </div>
   