
<div id="wapper_login">
        <!--<div class="name_product"></div>-->
        <div class="content" id="content">
            <form  method="post" accept-charset="utf-8"> 
<div  style="margin-top: 52px; ">
    Hệ thống đã gửi email tới email của bạn. Vui lòng check mail và thực hiện đúng thao tác !
</div>

<div class="account_login">
    
</div>

</form></div>
        </div>
        <!--<div class="version">Version: 2.0</div>
        <div class="copy">Copyright 2010 - All rights reserved.</div>-->
    </div>
   