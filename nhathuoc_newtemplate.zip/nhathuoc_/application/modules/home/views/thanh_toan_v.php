<div class="manual_cat">
	<div class="man_top">
		<div class="man_top_l"><img class="spacer" src="<?php echo base_url();?>template/ezwebvietnam/nhathuoc_template/images/spacer.gif"></div>
		<div class="man_top_m">Hướng dẫn thanh toán</div>
		<div class="man_top_r"><img class="spacer" src="<?php echo base_url();?>template/ezwebvietnam/nhathuoc_template/images/spacer.gif"></div>
	</div>
	<!--end .man_top-->
	<div class="clear"></div>
	<div class="manual_cat_">
		<div class="man_detail_title">
			<h1>Hướng dẫn thanh toán</h1>
		</div>
		
		<div class="man_detail_desc">
			<table border="1" bordercolor="#DBDBDB" cellpadding="10" cellspacing="10" rules="all" style="width: 100%; border-collapse: collapse;">
	<tbody>
	<?php 
	foreach($list_payment as $l_payment)
	{
	?>
		<tr>
			<td valign="top">
			<?php 
			if(file_exists(PATH_FOLDER.ROT_DIR.'file/uploads/bank/'.$l_payment['image']) && is_file(PATH_FOLDER.ROT_DIR.'file/uploads/bank/'.$l_payment['image']) && $l_payment['image']!='')
			{
			
			?>
				<img alt="<?php echo $l_payment['name']?>" src="<?php echo base_url();?>file/uploads/bank/<?php echo $l_payment['image']?>" width="150" height="80">
					<?php } else { ?>
					<img alt="<?php echo $l_payment['name']?>" src="<?php echo base_url();?>file/uploads/no_image.gif" width="150" height="80">
					<?php } ?>
				</td>
			<td valign="top">
				<strong>Chủ tài khoản: </strong><?php echo $l_payment['name_account'];?><br>
				<strong>Số tài khoản: </strong><?php echo $l_payment['account_number']?><br>
				<strong>Tại:</strong> <?php echo $l_payment['name']?> <!-- All --></td>
		</tr>
	<?php } ?>	
	</tbody>
</table>
		</div>
		<!--end .man_detail_desc-->
		<div class="clear"></div>
		<div class="man_detail_share">
			<div class="clear"><img height="5px" src="<?php echo base_url();?>template/ezwebvietnam/nhathuoc_template/images/spacer.gif"></div>
			<div class="go_back"><a href="javascript:history.go(-1);">Trở về trang trước</a> <img src="<?php echo base_url();?>template/ezwebvietnam/nhathuoc_template/images/go_back.png"></div>
			<div class="clear"><img height="5px" src="<?php echo base_url();?>template/ezwebvietnam/nhathuoc_template/images/spacer.gif"></div>
			<div id="share_tool">
				<div class="addthis_toolbox addthis_default_style ">
					<a class="addthis_button_preferred_1"></a>
					<a class="addthis_button_preferred_2"></a>
					<a class="addthis_button_preferred_3"></a>
					<a class="addthis_button_compact at300m" href="#"><span class="at16nc at300bs at15nc at15t_compact at16t_compact"><span class="at_a11y">More Sharing Services</span></span></a>
					<a class="addthis_counter addthis_bubble_style"></a>
					<div class="atclear"></div>
				</div>
				<div class="print_mail">
					<a href="javascript:print()" class="print">In</a>
					<a href="mailto:youremail@example.com?body=<?php echo full_url_($_SERVER);?>" class="mail">Gửi mail</a>
				</div>
				<script type="text/javascript"> var addthis_config = {"data_track_clickback":true};</script>
				<script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=ra-4dd331294ee7e605"></script>
				<div id="_atssh" style="visibility: hidden; height: 1px; width: 1px; position: absolute; z-index: 100000;"><iframe id="_atssh225" title="AddThis utility frame" src="//s7.addthis.com/static/r07/sh165.html#iit=1405927675781&amp;tmr=load%3D1405927661842%26core%3D1405927671193%26main%3D1405927675693%26ifr%3D1405927675802&amp;cb=0&amp;cdn=0&amp;chr=UTF-8&amp;kw=Gi%E1%BA%A3m%20b%C3%A9o%20to%C3%A0n%20di%E1%BB%87n%20t%E1%BB%AB%20trong%20ra%20ngo%C3%A0i%2Ckhuy%E1%BA%BFn%20m%C3%A3i%20s%C3%B3c%2Cgi%E1%BA%A3m%20c%C3%A2n%20hi%E1%BB%87u%20qu%E1%BA%A3%2Cc%C3%A1ch%20gi%E1%BA%A3m%20c%C3%A2n.&amp;ab=-&amp;dh=nhathuoc365.vn&amp;dr=http%3A%2F%2Fnhathuoc365.vn%2Ftin-khuyen-mai.html&amp;du=http%3A%2F%2Fnhathuoc365.vn%2Ftin-khuyen-mai%2Fgiam-beo-toan-dien-tu-trong-ra-ngoai.html&amp;dt=Gi%E1%BA%A3m%20b%C3%A9o%20to%C3%A0n%20di%E1%BB%87n%20t%E1%BB%AB%20trong%20ra%20ngo%C3%A0i&amp;dbg=0&amp;md=0&amp;cap=tc%3D0%26ab%3D0&amp;inst=1&amp;vcl=1&amp;jsl=161&amp;prod=undefined&amp;lng=vi&amp;ogt=&amp;pc=men&amp;pub=ra-4dd331294ee7e605&amp;ssl=0&amp;sid=53ccc0f764dd62f2&amp;srpl=1&amp;srcs=1&amp;srd=1&amp;srf=1&amp;srx=1&amp;ver=300&amp;xck=0&amp;xtr=0&amp;og=&amp;aa=0&amp;csi=undefined&amp;rev=1405430506&amp;ct=1&amp;xld=1&amp;xd=1" style="height: 1px; width: 1px; position: absolute; z-index: 100000; border: 0px; left: 0px; top: 0px;"></iframe></div>
				<script type="text/javascript" src="http://s7.addthis.com/static/r07/core143.js"></script>
			</div>
		</div>
		<!--end .man_detail_share-->
		<div class="clear"></div>
		
		<!--end .man_detail_other-->
		<div class="clear"><img height="10px" src="<?php echo base_url();?>template/ezwebvietnam/nhathuoc_template/images/spacer.gif"></div>
		<div class="clear"><img height="10px" src="<?php echo base_url();?>template/ezwebvietnam/nhathuoc_template/images/spacer.gif"></div>
		
		<script src="<?php echo base_url();?>template/ezwebvietnam/nhathuoc_template/js/jquery.carouFredSel.js" type="text/javascript"></script>               
		<div class="clear"><img class="spacer" src="<?php echo base_url();?>template/ezwebvietnam/nhathuoc_template/images/spacer.gif"></div>
	</div>
	<!--end .manual_cat_-->
	<div class="clear"></div>
	<div class="man_bot">
		<div class="man_bot_l"><img class="spacer" src="<?php echo base_url();?>template/ezwebvietnam/nhathuoc_template/images/spacer.gif"></div>
		<div class="man_bot_m"><img class="spacer" src="<?php echo base_url();?>template/ezwebvietnam/nhathuoc_template/images/spacer.gif"></div>
		<div class="man_bot_r"><img class="spacer" src="<?php echo base_url();?>template/ezwebvietnam/nhathuoc_template/images/spacer.gif"></div>
	</div>
	<!--end .man_bot-->
</div>
