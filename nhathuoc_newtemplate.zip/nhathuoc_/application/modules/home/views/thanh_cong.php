<div id="main_content">
						<div id="nav_link">
							<a href="/">Trang chủ</a><span> &gt; </span><a href="/nhom-hang.html">Sản phẩm</a><span> &gt; </span><a href="<?php echo full_url_($_SERVER);?>" class="">Thanh toán thành công</a>
						</div>
						<!--end #nav_link-->		 
						<div class="clear"><img height="7px" src="<?php echo base_url();?>template/ezwebvietnam/nhathuoc_template/images/spacer.gif" /></div>
						<div class="product_list">
							
							
							<!--end #hot_product-->
							<div class="clear"><img height="15px" src="<?php echo base_url();?>template/ezwebvietnam/nhathuoc_template/images/spacer.gif" /></div>
							<div class="main_title">
								<div class="main_title_l"><img class="spacer" src="<?php echo base_url();?>template/ezwebvietnam/nhathuoc_template/images/spacer.gif" /></div>
								<div class="main_title_m">
									
									
									
								</div>
								<!--end .main_title_m-->
								<div class="main_title_r"><img class="spacer" src="<?php echo base_url();?>template/ezwebvietnam/nhathuoc_template/images/spacer.gif" /></div>
							</div>
							<!--end #main_title-->
						
							<!--end .product_cat_item-->
							<center>
										Cảm ơn quý khách đã đặt hàng !<br>Mã đơn hàng của quý khách là: <font size="20px" color="red"><b><?php echo $_GET['code']?></b></font><br>
										Để theo dõi tình trạng của đơn hàng, xin click vào link <a href="<?php echo base_url();?>tinh-trang-don-hang?code=<?php echo $_GET['code']?>">Tình trạng đơn hàng</a>
									</center>
							<!--end .product_cat_item-->
							<div class="main_title">
								<div class="main_title_l"><img class="spacer" src="<?php echo base_url();?>template/ezwebvietnam/nhathuoc_template/images/spacer.gif" /></div>
								<div class="main_title_m">
									<div class="count_pro"><span></span></div>
									<div class="page_pro">
										<div id="page_break">
											
										</div>
									</div>
								</div>
								<!--end .main_title_m-->
								<div class="main_title_r"><img class="spacer" src="<?php echo base_url();?>template/ezwebvietnam/nhathuoc_template/images/spacer.gif" /></div>
							</div>
							<!--end #main_title-->
							<div class="clear"><img class="spacer" src="<?php echo base_url();?>template/ezwebvietnam/nhathuoc_template/images/spacer.gif" /></div>
							<a id="go_top" href="#" >Lên đầu trang</a>
							<div class="clear"></div>
						</div>
						<div class="clear"><img height="10px" src="<?php echo base_url();?>template/ezwebvietnam/nhathuoc_template/images/spacer.gif" /></div>
					</div>