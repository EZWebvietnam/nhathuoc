<div id=":1yk" class="ii gt m14597004f6943eeb adP adO">
   <div id=":1yj" class="a3s" style="overflow: hidden;">
      <div style="background:#f6f6f6;padding:35px 20px 20px 20px">
         <table cellspacing="0" cellpadding="0" width="100%" align="center">
            <tbody>
               <tr style="height:75px;background:#127fc0">
                  <td style="padding:0 15px"><a href="<?php echo base_url();?>" style="color:#fff;font-weight:bold;display:block;float:left;font-size:28px;line-height:75px;text-decoration:none" target="_blank">TibiMart.com</a> <span style="font-size:24px;color:#fff;padding-left:260px;display:block;line-height:75px"></span></td>
               </tr>
               <tr style="background:#fff">
                  <td style="color:#444444;border:1px solid #dddddd;padding:0 20px">
                     <p style="font-size:18px;color:#444444;font-weight:bold">Mật khẩu mới tại TibiMart.com</p>
                     <p>Xin chào !,</p>
                     <p>Quý khách đã thực hiện chức năng reset password tại TibiMart.com</p>
                     <p>Mật khẩu đã được reset thành công.</p>
                    <p>Username:<?php echo $username?></p>	
                    <p>Password:<?php echo $password?></p>	
                    <p>Vui lòng thay đổi mật khẩu ngay sau khi đăng nhập !</p>	
                     <p>Chúc quý khách hàng có một ngày tốt lành tại  <a href="<?php echo base_url();?>" style="font-size:14px;color:#004c92;text-decoration:none" target="_blank">TibiMart.com</a>! </p>
                     <p>Trân trọng,<br>Đội ngũ tibimart.com.</p>
                  </td>
               </tr>
               <tr>
                  <td>
                     <table cellpadding="0" cellspacing="0" align="center">
                        <tbody>
                           <tr>
                              <td colspan="3" align="center" style="padding:20px 0"><a href="http://www.hathanhauto.com" style="font-size:12px;color:#444444;text-decoration:none" target="_blank">@ <?php echo date('Y');?> Tibimart.com</a></td>
                           </tr>
                           <tr>
                              <td style="padding-right:30px;line-height:1.5em"><b>Tibimart.com – Tiện ích trong từng sản phẩm.</b><br>Số 40, Đường 13, Quốc lộ 13, Phường Hiệp Bình Chánh, Quận Thủ Đức – TPHCM</td>
                           </tr>
                        </tbody>
                     </table>
                  </td>
               </tr>
            </tbody>
         </table>
      </div>
      <div class="yj6qo"></div>
      <div class="adL"> </div>
   </div>
</div>