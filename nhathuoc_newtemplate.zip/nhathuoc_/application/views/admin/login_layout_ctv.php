
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd"> 
<html>
<head>
    <title>Quản lý bán hàng Online - VSale</title> 
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="description" content="phan mem quan ly ban hang, quan ly ban hang truc tuyen, ban hang, quan ly ban hang online, quản lý bán hàng">
    <meta name="keywords" content="phan mem quan ly ban hang, quan ly ban hang truc tuyen, ban hang, quan ly ban hang online, quản lý bán hàng">
    <script type="text/javascript" src="<?php echo base_url();?>template/ezwebvietnam/admin_cp/js/jquery.js" charset="UTF-8"></script>
<script type="text/javascript" src="<?php echo base_url();?>template/ezwebvietnam/admin_cp/js/core/360vnit.alert.js" charset="UTF-8"></script>
<script type="text/javascript" src="<?php echo base_url();?>template/ezwebvietnam/admin_cp/js/core/login.js" charset="UTF-8"></script>
<link type="text/css" rel="stylesheet" href="<?php echo base_url();?>template/ezwebvietnam/admin_cp/css/dangnhap.css" media="screen" />
<link type="text/css" rel="stylesheet" href="<?php echo base_url();?>template/ezwebvietnam/admin_cp/css/360vnit.alert.css" media="screen" />
</head>
<body>
    <?php echo $this->load->view($main_content);?>
</body>
</html>