﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'es', {
	copy: 'Copyright &copy; $1. Todos los derechos reservados.',
	dlgTitle: 'Acerca de CKEditor',
	help: 'Lea la  $1 para resolver sus dudas.',
	moreInfo: 'Para información de licencia, por favor visite nuestro sitio web:',
	title: 'Acerca de CKEditor',
	userGuide: 'Guía de usuario de CKEditor'
});
